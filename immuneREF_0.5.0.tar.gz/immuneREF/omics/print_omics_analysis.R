#' CALCULATES Omics LAYER CHARACTERISTICS
#'
#' @param OmicMatrix preprocessed omics data
#' @param SampleInfo metadata that allows matrix row/col naming
#' @param method method to calculate omics similarity options: PearsonCorr (PC, PC_centered, PC_scaled), PCA(70|100), Mutual Information (MI), Highest Reciprocal Ranks (HRR),

#' @return omics similarity layer of repertoire layers
#' @examples
#' \dontrun{
#' calculate_omics_layer(repertoire_df,models=list(svm_public_mm=svm_model_public),species,receptor,chain,identifier_rep,vdj_list=list_germline_genes,dictionary=dictionary_counts)
#' }

print_omics_data <- function(OmicMatrix,SampleInfo){

  #@TRMA code for plots

}
