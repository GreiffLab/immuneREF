#' CALCULATES Omics LAYER CHARACTERISTICS
#'
#' @param OmicMatrix preprocessed omics data
#' @param method method to calculate omics similarity options: PearsonCorr (PC, PC_centered, PC_scaled), PCA(70|100), Mutual Information (MI), Mutual Rank (MR),Highest Reciprocal Ranks (HRR),
#' @param sd_threshold minimal standard deviation threshold for a gene to be kept
#' @return omics similarity layer of repertoire layers
#' @examples
#' \dontrun{
#' calculate_omics_layer(repertoire_df,models=list(svm_public_mm=svm_model_public),species,receptor,chain,identifier_rep,vdj_list=list_germline_genes,dictionary=dictionary_counts)
#' }


#CRW: is sampleInfo needed or can we require it to be present in omic matrix already?
#      it is not added everywhere, is there a reason?
#     are the matrices that get calculated in the same format for all?
#     which packages are essential to add? heatmap of to us same as before?


calculate_omics_layer <- function(OmicMatrix, method="PC", sd_threshold=1, pca_threshold=0.8){

  # 1) Dataset and metadata ----
  ## dataset = omic matrix with features as rows and observations as columns
  ## (we asume that the omic matrix is already normalized and filtered by low counts)
  ## metadata = table with minimum 2 columns: sample IDs (here, "SampleID") and experimental condition (here, "Group")
  #OmicMatrix <- load("rnaseqCQN.Rda")
  #SampleInfo <- read.csv("SampleInfo.csv")
  #ColorList <- list(c("orange", "olivedrab3", "mediumpurple")) # as many as experimental conditions


  # 2) Network Analysis ----

  ## Step 1: filtering low expressed features by standard deviation ----
  sd_val <- apply(OmicMatrix, 1, sd)
  selected_variables_SD <- names(which(sd_val > sd_threshold))
  mydata <- OmicMatrix[selected_variables_SD,]


  ## Step 2: correlation methods ----

  if(method == "PC"){

    #### centered by feature (rows) ----
    omics_similarity <-cor(mydata)

    #NMF::aheatmap(cor(PC_centered),
    #              main = "Pearson Correlation - centered",
    #              annCol = data.frame(Group = SampleInfo$Group),
    #              annRow = data.frame(Group = SampleInfo$Group),
    #              annColors = ColorList)

  }else if(method=="PC_centered"){

    omics_similarity <- t(base::scale(t(mydata), center = T, scale = F))



  }else if(method=="PC_centered_scaled"){

    #### centered + scaled by feature (rows) ----
    omics_similarity <- t(base::scale(t(mydata), center = T, scale = T))

    #PC_centered_scaled_heatmap <- NMF::aheatmap(cor(PC_centered_scaled),
    #                                            main = "Pearson Correlation - centered + scaled",
    #                                            annCol = data.frame(Group = SampleInfo$Group),
    #                                            annRow = data.frame(Group = SampleInfo$Group),
    #                                            annColors = ColorList)

  }
  else if(method=="MI"){
    ### Option 2: Mutual Information (MI) ----

    # minet requires data.frame where columns contain variables/features and rows contain outcomes/samples
    # we traspose the matrix to obtain a network with samples as edges
    omics_similarity <- minet::minet(mydata, method = "mrnet", estimator = "mi.empirical", disc = "equalwidth", nbins = sqrt(nrow(mydata)))


    #MI_heatmap <- NMF::aheatmap(MI,
    #                            main = "Mutual information",
    #                            annCol = data.frame(Group = SampleInfo$Group),
    #                            annRow = data.frame(Group = SampleInfo$Group),
    #                            annColors = ColorList)
  }else if(method == "MR"){

    ### Option 3: Mutual Rank (MR) ----
    gene.data <- t(mydata)
    number.of.genes <- ncol(mydata)

    R <- matrix(NA, nrow = number.of.genes, ncol = number.of.genes)
    # Compute correlation ranks for each gene
    for(i in 1:number.of.genes) {
      # Rank all genes relative to gene i
      # Use 1-cor() because rank() uses ascending order
      R[i,] <- base::rank(apply(gene.data, 1, function(x) 1-cor(gene.data[i,],x)))
    }

    omics_similarity <- sqrt(R *t(R)) # Mutual rank
    #CRW: extract beforehand and thus get rid of SampleInfo.
    #rownames(omics_similarity) <- SampleInfo$SampleID
    #colnames(omics_similarity) <- SampleInfo$SampleID


    #MR_heatmap <- NMF::aheatmap(MR,
    #                            main = "Mutual rank",
    #                            annCol = data.frame(Group = SampleInfo$Group),
    #                            annRow = data.frame(Group = SampleInfo$Group),
    #                            annColors = ColorList)

  }else if(method == "HRR"){
    ### Option 4: Highest Reciprocal Ranks (HRR) ----
    omics_similarity <- base::pmax(R , t(R))
    rownames(omics_similarity) <- SampleInfo$SampleID
    colnames(omics_similarity) <- SampleInfo$SampleID

    #HRR_heatmap <- NMF::aheatmap(HRR,
    #                             main = "Highest reciprocal ranks",
    #                             annCol = data.frame(Group = SampleInfo$Group),
    #                             annRow = data.frame(Group = SampleInfo$Group),
    #                             annColors = ColorList)


  }else if(method =="PCA" | method=="PCA_100"){

    ### Option 5: Principal Component Analysis (PCA) ----
    mydata_noiseq <- NOISeq::readData(mydata, factors = SampleInfo[,c("SampleID","Group")])
    myPCA <- NOISeq::dat(mydata_noiseq, type = "PCA", logtransf = T, norm = T)

    if(method == "PCA"){
      #### Opt1: 70% explained variability ----
      # selecting components (condition: >70% explained variability)
      ncomp <- which(myPCA@dat$result$var.exp[,2] > pca_threshold)[1]

      score_matrix <- myPCA@dat$result$scores[,1:ncomp]
      rownames(score_matrix) <- SampleInfo$SampleID

      omics_similarity <- cor(t(score_matrix))

      #PCA70_heatmap <- NMF::aheatmap(PCA70,
      #                               main = "PCA scores (70% exp var)",
      #                               annCol = data.frame(Group = SampleInfo$Group),
      #                               annRow = data.frame(Group = SampleInfo$Group),
      #                               annColors = ColorList)

    }else if(method == "PCA_100"){

      #### Opt2: 100% explained variability with Residuals ----
      X <- mydata
      scores <- myPCA@dat$result$scores[,1:ncomp]
      loadings <- myPCA@dat$result$loadings[,1:ncomp]
      residuals <- X - t(scores %*% t(loadings))

      square_sum <- colSums(residuals^2)
      score_matrix <- cbind(myPCA@dat$result$scores[,1:ncomp], square_sum)

      omics_similarity <- cor(t(score_matrix))

      #PCA100_heatmap <- NMF::aheatmap(PCA100,
      #                                main = "PCA scores (100% exp var)",
      #                                annCol = data.frame(Group = SampleInfo$Group),
      #                                annRow = data.frame(Group = SampleInfo$Group),
      #                                annColors = ColorList)
    }

  }

  return(omic_similarity)
}



#  # 3) Method Comparison ----
#  ## RData object to plot immuneREF mutual information plot
#  save(PC, PC_centered_scaled, MI, MR, HRR, PCA70, PCA100,
#       file = "omic_layer.RData")
#
#  ## Cophenetic correlation ----
#  heatmaps <- list("PC_heatmap" = PC_heatmap,
#                   "PC_centered_scaled_heatmap" = PC_centered_scaled_heatmap,
#                   "MI_heatmap" = MI_heatmap,
#                   "MR_heatmap" = MR_heatmap,
#                   "HRR_heatmap" = HRR_heatmap,
#                   "PCA70_heatmap" = PCA70_heatmap,
#                   "PCA100_heatmap" = PCA100_heatmap)
#
#  cophenetic_table <- do.call(rbind, lapply(heatmaps, function(x){
#    do.call(cbind, lapply(heatmaps, function(y){
#      dendextend::cor_cophenetic(x$Rowv, y$Rowv, method_coef = "spearman")
#    }))
#  }))
#  rownames(cophenetic_table) <- names(heatmaps)
#
#  corrplot::corrplot(cophenetic_table, type = "lower", method = "number")

