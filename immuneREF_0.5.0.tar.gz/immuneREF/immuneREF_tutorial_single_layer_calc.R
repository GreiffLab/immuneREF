#
#01 Main script to preprocess repertoires, calculate characteristics and calculate correlation matrix
#
library(immuneNET)
library(foreach)
library(doMC)
registerDoMC(1)


###FIX VDJ AND CHECK MAKECORMAT AND COMPARING NODES



setwd("/Users/ceweber/Desktop/PhD_year_one/Projects/09_immuneNET/vpackage.0.5.0/tutorial_immuneNET")

#check compatibility included reference file for germline gene namings 
head(list_germline_genes$hs$tr$b$J)

#load immunosignature ML models.
#make list of immunosignature ML models that immuneNET can access
model_list<-list()
model_list[[1]]<-svm_model_public

#for naming: size of repertoires (as they are simulated to 1000 no need to subsample)
subsample_size<-10000

##for kmer-occurrence layer: if non standard params: define parameters and prepare empty dictionary. 
#dictionary_counts<-make_kmer_dictionary(k_nt=3,k_aa=1,gap_size_nt=c(0,1,2,3),gap_size_aa=c(0,1))




#Load/check datasets and compatibility

head(tutorial_repertoires[[1]])

list_simulated_repertoires <- tutorial_repertoires #from: list_sim_reps_v05_A[1:5]


#if incompatible necessary: rename columns to be immmuneNET compliant (dataset dependent)
if(table(c("sequence", "junction", "sequence_aa", "junction_aa","freqs","v_call","d_call","j_call") %in% names(list_simulated_repertoires[[1]]))[[TRUE]] == 8){
  cat("all columns present\n")

}else{
  cat("need to rename/add columns")

  #for(i in 1:length(list_simulated_repertoires)){
  #  curr_repertoire<-list_simulated_repertoires[[i]]
  #  
  #  names(curr_repertoire)[[1]]<-"N..Seq..VDJ"
  #  names(curr_repertoire)[[2]]<-"AA..Seq.VDJ"
  #  names(curr_repertoire)[[3]]<-"N..Seq..CDR3"
  #  names(curr_repertoire)[[4]]<-"AA..Seq.CDR3"
  #  names(curr_repertoire)[[17]]<-"Clone.count"
  #  names(curr_repertoire)[[5]]<-"All.V.hits"
  #  names(curr_repertoire)[[6]]<-"All.D.hits"
  #  names(curr_repertoire)[[7]]<-"All.J.hits"
  #  
  #  curr_repertoire[["AA..Seq.VDJ"]]<-as.character(curr_repertoire[["AA..Seq.VDJ"]])
  #  curr_repertoire[["N..Seq..VDJ"]]<-as.character(curr_repertoire[["N..Seq..VDJ"]])
  #  curr_repertoire[["AA..Seq.CDR3"]]<-as.character(curr_repertoire[["AA..Seq.CDR3"]])
  #  curr_repertoire[["N..Seq..CDR3"]]<-as.character(curr_repertoire[["N..Seq..CDR3"]])
  #        
  #  list_simulated_repertoires[[i]] <- curr_repertoire
  #}
} 

error<-compatibility_check(repertoire=tutorial_repertoires[[1]], species="mm", receptor="igh")
error<-compatibility_check(repertoire=tutorial_repertoires[[2]], species="mm", receptor="igh")
error<-compatibility_check(repertoire=tutorial_repertoires[[3]], species="hs", receptor="igh")
error<-compatibility_check(repertoire=tutorial_repertoires[[4]], species="hs", receptor="igh")

stopifnot(error==0)

#calculate overlap layer
overlap_layer<-repertoire_overlap(list_simulated_repertoires,basis="CDR3_aa")
#save(overlap_layer,file="output/feature_analysis/overlap_layer")



#set number of repertoires to be analyzed and names for reference
repertoire_names <- names(list_simulated_repertoires)
repertoire_lengths <- sapply(list_simulated_repertoires,nrow)
repertoire_species <- sapply(strsplit(repertoire_names, "\\_"),function(x) x[[1]])
repertoire_receptor <- sapply(strsplit(repertoire_names, "\\_"),function(x) x[[2]])
repertoire_chain <- sapply(strsplit(repertoire_names, "\\_"),function(x) x[[3]])

input_data_ref<-data.frame(sample_id = repertoire_names,
                           nb_sequences = repertoire_lengths,
                           species = repertoire_species,
                           receptor = repertoire_receptor,
                           chain = repertoire_chain,row.names=c(1:length(repertoire_names)))


#subsample for the ones that are not 10000
subsample_size <- 100

list_simulated_repertoires<-subset_input_repertoires(list_repertoires=list_simulated_repertoires,
                               subset_size=subsample_size,
                               random=FALSE)



#########################################
#Example of separate layers calculation #
#########################################

#Prepare list of lists for single feature analysis results
# include entries for repertoire metadata (species,receptor,repertoirename,numberofseqs)
repertoires_analyzed<-list()
for(z in 1:length(list_simulated_repertoires)){
  repertoires_analyzed[[z]] <- list()
  repertoires_analyzed[[z]][["diversity"]] <- list()
  repertoires_analyzed[[z]][["AA_freq"]] <- list()
  repertoires_analyzed[[z]][["average_degree"]] <- list()
  repertoires_analyzed[[z]][["immunosignatures"]] <- list()
  repertoires_analyzed[[z]][["vdj_diversity"]] <- list()
  repertoires_analyzed[[z]][["kmers_nt"]] <- list()
  repertoires_analyzed[[z]][["species"]] <- strsplit(repertoire_names[z],"_")[[1]][1]
  repertoires_analyzed[[z]][["receptor"]] <- paste(strsplit(repertoire_names[z],"_")[[1]][2],strsplit(repertoire_names[z],"_")[[1]][3],collapse="",sep="")
  repertoires_analyzed[[z]][["repertoire"]] <- repertoire_names[z]
  repertoires_analyzed[[z]][["number_of_seqs"]] <- repertoire_lengths[z]
}



#analyze each feature separately 
repertoires_analyzed_diversity <- repertoires_analyzed
repertoires_analyzed_diversity<-foreach(i=1:length(list_simulated_repertoires)) %dopar% {


#for(i in 1:length(list_simulated_repertoires)){
  cat("i:", i, "\n")
  single_characteristic<-recalc_single_characteristic(analyzed_list=repertoires_analyzed[[i]],
                                                                   characteristic="Evenness",
                                                                   repertoire_df=list_simulated_repertoires[[i]],
                                                                   models=model_list,
                                                                   species=repertoires_analyzed[[i]][["species"]],
                                                                   receptor=substr(repertoires_analyzed[[i]][["receptor"]],1,2),
                                                                   chain=substr(repertoires_analyzed[[i]][["receptor"]],3,3),
                                                                   identifier_rep=repertoires_analyzed[[i]][["repertoire"]],
                                                                   vdj_list=list_germline_genes,
                                                                   dictionary=dictionary_counts)
  return(single_characteristic)
}

names(repertoires_analyzed_diversity)<-unlist(sapply(1:length(repertoires_analyzed_diversity),function(x) repertoires_analyzed_diversity[[x]][["repertoire"]]))
save(repertoires_analyzed_diversity,file=paste("output/feature_analysis/sim_repertoires_analyzed_diversity_",subsample_size,"_seqs_",length(repertoires_analyzed_diversity),"_samples",sep=""))

list_single_layers_sims<-list()
list_single_layers_sims[[1]]<-make_cormat(repertoires_analyzed_diversity,weights_VDJ=c(1,1,1),weights_overall=c(1,0,0,0,0,0),correlation_method='spearman')
save(list_single_layers_sims,file=paste("output/single_layers/cor_matrix_single_layers_sim_samples_",nrow(list_single_layers_sims[[1]]),"_tmp",sep=""))

rm(repertoires_analyzed_diversity)

  
repertoires_analyzed_AAfreq <- repertoires_analyzed
repertoires_analyzed_AAfreq<-foreach(i=1:length(list_simulated_repertoires)) %dopar% {
#for(i in 1:length(list_simulated_repertoires)){
  cat("i:", i, "\n")
  single_characteristic<-recalc_single_characteristic(analyzed_list=repertoires_analyzed[[i]],
                                                                    characteristic="AA_frequency",
                                                                    repertoire_df=list_simulated_repertoires[[i]],
                                                                    models=model_list,
                                                                    species=repertoires_analyzed[[i]][["species"]],
                                                                    receptor=substr(repertoires_analyzed[[i]][["receptor"]],1,2),
                                                                    chain=substr(repertoires_analyzed[[i]][["receptor"]],3,3),
                                                                    identifier_rep=repertoires_analyzed[[i]][["repertoire"]],
                                                                    vdj_list=list_germline_genes,
                                                                    dictionary=dictionary_counts)

  return(single_characteristic)
}
names(repertoires_analyzed_AAfreq)<-unlist(sapply(1:length(repertoires_analyzed_AAfreq),function(x) repertoires_analyzed_AAfreq[[x]][["repertoire"]]))
save(repertoires_analyzed_AAfreq,file=paste("output/feature_analysis/sim_repertoires_analyzed_AAfreq_",subsample_size,"_seqs_",length(repertoires_analyzed_AAfreq),"_samples",sep=""))

list_single_layers_sims[[2]]<-make_cormat(repertoires_analyzed_AAfreq,weights_VDJ=c(1,1,1),weights_overall=c(0,1,0,0,0,0),correlation_method='spearman')
save(list_single_layers_sims,file=paste("output/single_layers/cor_matrix_single_layers_sim_samples_",nrow(list_single_layers_sims[[2]]),"_tmp",sep=""))

rm(repertoires_analyzed_AAfreq)



repertoires_analyzed_immunosignatures <- repertoires_analyzed
repertoires_analyzed_immunosignatures<-foreach(i=1:length(list_simulated_repertoires)) %dopar% {
#for(i in 1:length(list_simulated_repertoires)){
  cat("i:", i, "\n")
  single_characteristic<-recalc_single_characteristic(analyzed_list=repertoires_analyzed[[i]],
                                                                    characteristic="Immunosignatures",
                                                                    repertoire_df=list_simulated_repertoires[[i]],
                                                                    models=model_list,
                                                                    species=repertoires_analyzed[[i]][["species"]],
                                                                    receptor=substr(repertoires_analyzed[[i]][["receptor"]],1,2),
                                                                    chain=substr(repertoires_analyzed[[i]][["receptor"]],3,3),
                                                                    identifier_rep=repertoires_analyzed[[i]][["repertoire"]],
                                                                    vdj_list=list_germline_genes,
                                                                    dictionary=dictionary_counts)
  return(single_characteristic)
}
names(repertoires_analyzed_immunosignatures)<-unlist(sapply(1:length(repertoires_analyzed_immunosignatures),function(x) repertoires_analyzed_immunosignatures[[x]][["repertoire"]]))
save(repertoires_analyzed_immunosignatures,file=paste("output/feature_analysis/sim_repertoires_analyzed_immunosignatures_",subsample_size,"_seqs_",length(repertoires_analyzed_immunosignatures),"_samples",sep=""))

list_single_layers_sims[[4]]<-make_cormat(repertoires_analyzed_immunosignatures,weights_VDJ=c(1,1,1),weights_overall=c(0,0,0,1,0,0),correlation_method='spearman')
save(list_single_layers_sims,file=paste("output/single_layers/cor_matrix_single_layers_sim_samples_",nrow(list_single_layers_sims[[4]]),"_tmp",sep=""))

rm(repertoires_analyzed_immunosignatures)


repertoires_analyzed_vdj_diversity <- repertoires_analyzed
repertoires_analyzed_vdj_diversity<-foreach(i=1:length(list_simulated_repertoires)) %dopar% {
#for(i in 1:length(list_simulated_repertoires)){
  cat("i:", i, "\n")
  single_characteristic<-recalc_single_characteristic(analyzed_list=repertoires_analyzed[[i]],
                                                                           characteristic="VDJ_usage",
                                                                           repertoire_df=list_simulated_repertoires[[i]],
                                                                           models=model_list,
                                                                           species=repertoires_analyzed[[i]][["species"]],
                                                                           receptor=substr(repertoires_analyzed[[i]][["receptor"]],1,2),
                                                                           chain=substr(repertoires_analyzed[[i]][["receptor"]],3,3),
                                                                           identifier_rep=repertoires_analyzed[[i]][["repertoire"]],
                                                                           vdj_list=list_germline_genes,
                                                                           dictionary=dictionary_counts)
  single_characteristic
}
names(repertoires_analyzed_vdj_diversity)<-unlist(sapply(1:length(repertoires_analyzed_vdj_diversity),function(x) repertoires_analyzed_vdj_diversity[[x]][["repertoire"]]))
save(repertoires_analyzed_vdj_diversity,file=paste("output/feature_analysis/sim_repertoires_analyzed_vdj_diversity_",subsample_size,"_seqs_",length(repertoires_analyzed_vdj_diversity),"_samples",sep=""))

list_single_layers_sims[[5]]<-make_cormat(repertoires_analyzed_vdj_diversity,weights_VDJ=c(1,1,1),weights_overall=c(0,0,0,0,1,0),correlation_method='spearman')
save(list_single_layers_sims,file=paste("output/single_layers/cor_matrix_single_layers_sim_samples_",nrow(list_single_layers_sims[[5]]),"_tmp",sep=""))

rm(repertoires_analyzed_vdj_diversity)



repertoires_analyzed_kmers_nt <- repertoires_analyzed
repertoires_analyzed_kmers_nt<-foreach(i=1:length(list_simulated_repertoires)) %dopar% {
#for(i in 1:length(list_simulated_repertoires)){
  cat("i:", i, "\n")
  single_characteristic<-recalc_single_characteristic(analyzed_list=repertoires_analyzed[[i]],
                                                                        characteristic="kmer_occurrence",
                                                                        repertoire_df=list_simulated_repertoires[[i]],
                                                                        models=model_list,
                                                                        species=repertoires_analyzed[[i]][["species"]],
                                                                        receptor=substr(repertoires_analyzed[[i]][["receptor"]],1,2),
                                                                        chain=substr(repertoires_analyzed[[i]][["receptor"]],3,3),
                                                                        identifier_rep=repertoires_analyzed[[i]][["repertoire"]],
                                                                        vdj_list=list_germline_genes,
                                                                        dictionary=dictionary_counts)
  return(single_characteristic)
}
names(repertoires_analyzed_kmers_nt)<-unlist(sapply(1:length(repertoires_analyzed_kmers_nt),function(x) repertoires_analyzed_kmers_nt[[x]][["repertoire"]]))
save(repertoires_analyzed_kmers_nt,file=paste("output/feature_analysis/sim_repertoires_analyzed_kmers_nt_",subsample_size,"_seqs_",length(repertoires_analyzed_kmers_nt),"_samples",sep=""))

list_single_layers_sims[[6]]<-make_cormat(repertoires_analyzed_kmers_nt,weights_VDJ=c(1,1,1),weights_overall=c(0,0,0,0,0,1),correlation_method='pearson')
rm(repertoires_analyzed_kmers_nt)

names(list_single_layers_sims)<-c("Diversity","AAfreq","Architecture","Immunosignatures","VDJ_usage","k-mers")
save(list_single_layers_sims,file=paste("output/single_layers/cor_matrix_single_layers_sim_samples_",nrow(list_single_layers_sims[[6]]),"_tmp",sep=""))




#architecture
repertoires_analyzed_architecture <- repertoires_analyzed
repertoires_analyzed_architecture<-foreach(i=1:length(list_simulated_repertoires)) %dopar% {
#for(i in 1:length(list_simulated_repertoires)){
  cat("i:", i, "\n")
  single_characteristic<-recalc_single_characteristic(analyzed_list=repertoires_analyzed[[i]],
                                                                    characteristic="Architecture",
                                                                    repertoire_df=list_simulated_repertoires[[i]],
                                                                    models=model_list,
                                                                    species=repertoires_analyzed[[i]][["species"]],
                                                                    receptor=substr(repertoires_analyzed[[i]][["receptor"]],1,2),
                                                                    chain=substr(repertoires_analyzed[[i]][["receptor"]],3,3),
                                                                    identifier_rep=repertoires_analyzed[[i]][["repertoire"]],
                                                                    vdj_list=list_germline_genes,
                                                                    dictionary=dictionary_counts,
                                                                    architecture_depth=2)
  return(single_characteristic)
}
names(repertoires_analyzed_architecture)<-unlist(sapply(1:length(repertoires_analyzed_architecture),function(x) repertoires_analyzed_architecture[[x]][["repertoire"]]))
save(repertoires_analyzed_architecture,file=paste("output/feature_analysis/sim_repertoires_analyzed_architecture_",subsample_size,"_seqs_",length(repertoires_analyzed_architecture),"_samples",sep=""))

list_single_layers_sims[[3]]<-make_cormat(repertoires_analyzed_architecture,weights_VDJ=c(1,1,1),weights_overall=c(0,0,1,0,0,0),correlation_method='pearson')
save(list_single_layers_sims,file=paste("output/single_layers/cor_matrix_single_layers_sim_samples_",nrow(list_single_layers_sims[[3]]),"_all_layers",sep=""))

rm(repertoires_analyzed_architecture)



list_single_layers_sims[[7]]<-overlap_layer
names(list_single_layers_sims)<-c("Diversity","AAfreq","Architecture","Immunosignatures","VDJ_usage","k-mers","repertoire_overlap")
save(list_single_layers_sims,file=paste("output/single_layers/cor_matrix_single_layers_sim_samples_",nrow(list_single_layers_sims[[3]]),"_all_layers_plus_overlap",sep=""))



